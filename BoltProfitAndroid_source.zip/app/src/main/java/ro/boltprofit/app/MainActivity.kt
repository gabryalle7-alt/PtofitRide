package ro.boltprofit.app

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.provider.Settings
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.*
import android.graphics.Color
import android.text.InputType
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var result: TextView
    private lateinit var fare: EditText
    private lateinit var pickup: EditText
    private lateinit var trip: EditText
    private lateinit var consumption: EditText
    private lateinit var fuelPrice: EditText
    private lateinit var otherCost: EditText
    private lateinit var commission: EditText
    private lateinit var threshold: EditText

    private fun field(hint: String, value: String, decimal: Boolean = true): EditText {
        return EditText(this).apply {
            this.hint = hint
            setText(value)
            inputType = InputType.TYPE_CLASS_NUMBER or if (decimal) InputType.TYPE_NUMBER_FLAG_DECIMAL or InputType.TYPE_NUMBER_FLAG_SIGNED else 0
            textSize = 16f
            setPadding(18, 10, 18, 10)
        }
    }
    private fun label(text: String) = TextView(this).apply {
        this.text = text; textSize = 14f; setTextColor(Color.DKGRAY)
        setPadding(4, 10, 4, 2)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(20, 22, 20, 22)
            setBackgroundColor(Color.rgb(247,248,250))
        }
        val scroller = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(TextView(this).apply {
            text = "BOLT PROFIT / KM"; textSize = 24f; setTextColor(Color.rgb(20,35,55))
            setPadding(0,0,0,8)
        })
        content.addView(TextView(this).apply {
            text = "Calculator de rentabilitate • RON"; textSize = 14f; setTextColor(Color.GRAY)
        })
        fare = field("Venit net (lei)", "30")
        pickup = field("Km până la preluare", "3")
        trip = field("Km cu pasagerul", "8")
        consumption = field("Consum (l/100 km)", "7")
        fuelPrice = field("Preț combustibil (lei/l)", "7.5")
        otherCost = field("Alte costuri (lei/km)", "0.30")
        commission = field("Comision % (doar dacă venitul este brut)", "0")
        threshold = field("Prag profit (lei/km)", "1.50")
        listOf(
            "Venit net sau brut (dacă brut, setează comisionul)" to fare,
            "Distanță până la preluare (km)" to pickup,
            "Distanță cu pasagerul (km)" to trip,
            "Consum mașină (litri/100 km)" to consumption,
            "Preț combustibil (lei/litru)" to fuelPrice,
            "Alte costuri estimate (lei/km)" to otherCost,
            "Comision platformă (%)" to commission,
            "Profit minim dorit (lei/km)" to threshold
        ).forEach { (title, edit) -> content.addView(label(title)); content.addView(edit) }

        val calc = Button(this).apply { text = "CALCULEAZĂ PROFITUL"; setOnClickListener { calculate() } }
        content.addView(calc)
        result = TextView(this).apply {
            textSize = 18f; setTextColor(Color.rgb(20,35,55))
            setPadding(12, 24, 12, 24)
            text = "Introdu datele cursei și apasă Calculează."
        }
        content.addView(result)
        val accessibility = Button(this).apply {
            text = "ACTIVEAZĂ CITIREA OFERTELOR"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        content.addView(accessibility)
        content.addView(TextView(this).apply {
            text = "Citirea automată necesită activarea manuală a serviciului de accesibilitate Android. Funcționează numai dacă Bolt expune informațiile ofertei în arborele de accesibilitate. Verifică textul citit; această versiune nu acceptă/refuză curse."
            textSize = 12f; setTextColor(Color.GRAY); setPadding(4, 16, 4, 8)
        })
        scroller.addView(content); root.addView(scroller); setContentView(root)
        calculate()
    }

    private fun num(e: EditText): Double = e.text.toString().trim().replace(",", ".").toDoubleOrNull() ?: 0.0
    private fun calculate() {
        val f = num(fare).coerceAtLeast(0.0)
        val km = num(pickup).coerceAtLeast(0.0) + num(trip).coerceAtLeast(0.0)
        val c = num(consumption).coerceAtLeast(0.0)
        val p = num(fuelPrice).coerceAtLeast(0.0)
        val oc = num(otherCost).coerceAtLeast(0.0)
        val fee = num(commission).coerceIn(0.0, 100.0)
        val net = f * (1.0 - fee / 100.0)
        val fuel = km * c / 100.0 * p
        val costs = fuel + km * oc
        val profit = net - costs
        val perKm = if (km > 0) profit / km else 0.0
        val min = num(threshold)
        val verdict = if (km <= 0) "INTRODU DISTANȚELE" else if (perKm >= min) "PESTE PRAG" else if (profit >= 0) "SUB PRAG" else "PIERDERE ESTIMATĂ"
        result.text = String.format(Locale("ro","RO"),
            "TOTAL: %.2f km\nVenit după comision: %.2f lei\nCombustibil: %.2f lei\nAlte costuri: %.2f lei\nPROFIT ESTIMAT: %.2f lei\nPROFIT/KM: %.2f lei/km\n\n%s",
            km, net, fuel, km*oc, profit, perKm, verdict)
        result.setTextColor(if (km > 0 && perKm >= min) Color.rgb(15,125,65) else Color.rgb(175,65,45))
    }
}
