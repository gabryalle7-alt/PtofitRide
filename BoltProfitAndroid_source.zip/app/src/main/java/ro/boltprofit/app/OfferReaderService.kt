package ro.boltprofit.app

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.util.Log

/**
 * Prototype reader: observes text exposed by the Bolt Driver accessibility tree.
 * It does not click, accept, reject, or otherwise interact with trip controls.
 * The exact package name and text layout can vary by Bolt Driver version/region.
 */
class OfferReaderService : AccessibilityService() {
    private var lastText = ""
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val root = rootInActiveWindow ?: return
        val chunks = mutableListOf<String>()
        collectText(root, chunks)
        val combined = chunks.distinct().joinToString(" | ").trim()
        if (combined.isNotBlank() && combined != lastText) {
            lastText = combined
            // Prototype diagnostic only. Next step is matching verified offer fields.
            Log.i("BoltProfitReader", "Visible Bolt text: $combined")
        }
    }
    private fun collectText(node: AccessibilityNodeInfo?, out: MutableList<String>) {
        if (node == null) return
        node.text?.toString()?.takeIf { it.isNotBlank() }?.let { out.add(it) }
        node.contentDescription?.toString()?.takeIf { it.isNotBlank() }?.let { out.add(it) }
        for (i in 0 until node.childCount) collectText(node.getChild(i), out)
    }
    override fun onInterrupt() {}
}
