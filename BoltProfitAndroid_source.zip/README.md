# Bolt Profit/km — prototip Android

Aplicația include un calculator funcțional de profit și un serviciu prototip care încearcă să citească textul expus de aplicația Bolt Driver prin Android Accessibility Service.

## Important
- Acesta este cod-sursă Android, nu un APK compilat.
- Citirea automată este doar un prototip de diagnostic: textul este înregistrat în Logcat și încă nu este mapat automat în câmpurile calculatorului.
- Dacă Bolt desenează oferta fără text accesibil, serviciul nu va putea citi câmpurile; va fi necesară o abordare OCR bazată pe captură de ecran și permisiune Android MediaProjection.
- Numele pachetului Bolt poate varia. Dacă este necesar, actualizați `android:packageNames` în `app/src/main/res/xml/accessibility_service_config.xml`.
- Nu acceptă/refuză automat curse și nu apasă controale din Bolt.
- Folosiți citirea ecranului numai după ce verificați permisiunile, regulile platformei și legislația aplicabilă.

## Cum generezi APK-ul
1. Instalează Android Studio pe un PC.
2. Deschide folderul `BoltProfitAndroid`.
3. Lasă Android Studio să sincronizeze Gradle și instalează componentele SDK cerute.
4. Alege Build > Build APK(s).
5. Găsești APK-ul debug în `app/build/outputs/apk/debug/app-debug.apk`.
6. Transferă APK-ul pe telefonul Android și instalează-l. Este posibil să fie nevoie să permiți instalarea din sursa respectivă.
7. Deschide aplicația și testează mai întâi calculatorul. Pentru citire, activează serviciul în Setări Android > Accesibilitate > aplicații/servicii instalate.

## Calcul
Profit = venit după comision − combustibil − alte costuri.
Km total = km până la preluare + km cu pasagerul.
Profit/km = profit / km total.
